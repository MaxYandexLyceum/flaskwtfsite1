import os

from flask import Flask, url_for, request, render_template
from flask_wtf.file import FileRequired
from werkzeug.utils import redirect, secure_filename
from flask_wtf import FlaskForm, validators
from wtforms import StringField, PasswordField, BooleanField, SubmitField, FileField, TextAreaField
from wtforms.validators import DataRequired
from flask import Flask, flash, request, redirect, url_for
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
UPLOAD_FOLDER = '/static/data/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


@app.route('/<title>')
@app.route('/index/<title>')
def index(title):
    user = "Ученик Яндекс.Лицея"
    return render_template('base.html', title=title,
                           username=user)


@app.route('/distribution')
def distribution():
    data = ["Ридли Скотт", "Энди Уир", "Марк Уотни", "Венката Капур", "Тедди Сандерс", "Шон Бин"]
    return render_template('distribution.html', data=data)


@app.route('/table/<sex>/<age>')
def table(sex, age):
    age = int(age)
    return render_template('table.html', sex=sex, age=age)


class UploadFileForm(FlaskForm):
    file = FileField('File')

    submit = SubmitField('Отправить')


@app.route('/galery', methods=['GET', 'POST'])
def galery():
    images = []
    form = UploadFileForm(request.form)
    if form.validate_on_submit():
        filename = form.data["file"]
        # filename.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        images.append(filename)
    else:
        filename = None
    return render_template('galery.html', form=form, images=images)


class LoginForm(FlaskForm):
    username1 = StringField('id астронавта', validators=[DataRequired()])
    password1 = PasswordField('Пароль астронавта', validators=[DataRequired()])
    username2 = StringField('id капитана', validators=[DataRequired()])
    password2 = PasswordField('Пароль капитана', validators=[DataRequired()])
    submit = SubmitField('Доступ')


@app.route('/member')
def member():
    data = {"name": "Энди Уир", "img": "../static/data/uir.png", "description": "астрогеолог, специалист по радиационной защите"}
    return render_template('member.html', data=data)

@app.route('/training/<prof>')
def training(prof):
    return render_template('training.html', prof=prof)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        return redirect('/success')
    return render_template('login.html', form=form)


@app.route('/answer')
@app.route('/auto_answer')
def auto_answer():
    d = {"title": "Анкета", "surname": "Watny", "name": "Mark", "education": "выше среднего",
         "profession": "штурман марсохода", "sex": "male", "motivation": "Всегда мечатл застрять на Марсе!",
         "ready": "True"}
    return render_template('auto_answer.html', d=d)


@app.route('/list_prof/<list>')
def list_prof(list):
    ol = "False"
    ul = "False"
    m = ["инженер-исследователь", "пилот", "строитель", "экзобиолог", "врач", "инженер по терраформированию",
         "климатолог", "специалист по радиационной захщите", "астрогеолог", "гляциолог", "инженер жизнеобеспечения",
         "метеоролог",
         "оператор марсохода", "киберинженер", "штурман", "пилот дронов"]
    if list == "ol":
        ol = "True"
    else:
        ul = "True"
    return render_template('list_prof.html', ol=ol, ul=ul, m=m)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
